//
// Created by yue on 18-3-16.
//

#ifndef ARMAMODEL_H
#define ARMAMODEL_H


#include <vector>
#include "ARMAMath.h"
using namespace std;
class ARMAModel{
private:
	vector<double> data;
	int p;
	int q;

public:
	ARMAModel(vector<double> data, int p, int q){
		this->data = data;
		this->p = p;
		this->q = q;
	}

	vector<vector<double> > solveCoeOfARMA(){
		vector<vector<double> > vec;
		ARMAMath ar_math;

		vector<double> armaCoe(ar_math.computeARMACoe(this->data, p, q));
		vector<double> arCoe(this->p + 1);
		for (int i = 0; i<arCoe.size(); i++) arCoe[i] = armaCoe[i];

		vector<double>  maCoe(this->q + 1);

		for (int i = 0; i<maCoe.size(); i++) {
			maCoe[i] = armaCoe[i + this->p + 1];
		}
		vec.push_back(arCoe);
		vec.push_back(maCoe);

		return vec;
	}
};
#endif //ARMAMODEL_H
