/*************************************************************************
> File Name: ARMAMath.h
> Author: yue
> Mail:
> Created Time: 2018��03��15�� ������ 13ʱ44��00��
************************************************************************/

#ifndef _ARMAMATH_H
#define _ARMAMATH_H

#include <vector>
using namespace std;
class ARMAMath{
public:
	double avgData(vector<double> dataArray);
	double sumData(vector<double> dataArray);
	double stderrData(vector<double> dataArray);
	double varerrData(vector<double> dataArray);
	vector<double>  autocorData(vector<double> dataArray, int order);
	vector<double>  autocovData(vector<double> dataArray, int order);

	double mutalCorr(vector<double> dataFir, vector<double> dataSec);
	double getModelAIC(vector<vector<double> > vec, vector<double> data, int type);

	std::vector<vector<double> > LevinsonSolve(vector<double> garma);
	vector<double> computeARCoe(vector<double> dataArray, int p);
	vector<double> computeMACoe(vector<double> dataArray, int q);
	vector<double> computeARMACoe(vector<double> dataArray, int p, int q);

};



#endif

