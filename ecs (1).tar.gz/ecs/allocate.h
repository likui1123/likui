#ifndef ALLOCATE_H
#define ALLOCATE_H
#include <stdio.h>
#include <iostream>
#include "lib_io.h"
#include <vector>
#include <string>
#include <numeric>

using namespace std;

void allocate_simple(vector<string> vflavors, vector<int> vflavors_pridict_nums, string dim, char* filename);

#endif // ALLOCATE_H
