//
// Created by yue on 18-3-16.
//

#ifndef MAMODEL_H
#define MAMODEL_H

#include <vector>
#include "ARMAMath.h"
using namespace std;
class MAMoel{
private:
	vector<double> data;
	int p;

public:
	MAMoel(vector<double> data, int p);

	vector<vector<double> > solveCoeOfMA();
};
#endif //MAMODEL_H
