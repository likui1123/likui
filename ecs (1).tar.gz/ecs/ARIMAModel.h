//
// Created by yue on 18-3-16.
//

#ifndef ARIMAMODEL_H
#define ARIMAMODEL_H
#include <vector>
#include<math.h>
#include<stdlib.h>
#include "ARModel.h"
#include "MAModel.h"
#include "ARMAModel.h"
using namespace std;
int predict(vector<double> dataArray);

class ARIMAModel{
private:
	vector<double> dataArray;
	vector<double> dataFirDiff;

	vector<vector<double> > arima;
public:
	ARIMAModel(vector<double> dataArray) { this->dataArray.assign(dataArray.begin(), dataArray.end()); }

	vector<double> preFirDiff(vector<double> preData,int period){
		vector<double> res;
		for (int i = 0; i<preData.size() - period; i++){
			double tmpData = preData[i + period] - preData[i];
			res.push_back(tmpData);
		}
		return res;
	}

	vector<double> preSeasonDiff(vector<double> preData){
		vector<double> res;

		for (int i = 0; i<preData.size() - 3; i++){

			double tmpData = preData[i + 3] - preData[i];
			res.push_back(tmpData);
		}
		return res;
	}
	vector<double> preDealDiff(int period){//ѡ��7 ����Ϊ7  ���

		//cout << " c��ֹ���dataArray.size(): " << dataArray.size() << endl;
		if (period >= dataArray.size() - 1){//��6Ҳ��Ϊ�����Բ��
			
			period = 0;
		}

		switch (period){
		case 0: {
			return this->dataArray;//����ԭʼ����
			//cout << " ��ֹ���:ԭʼ���� " << endl;
		}
				break;
		case 1: {
			//cout << " ��ֹ���:һ�ײ�� " << endl;
			vector<double> tmp(this->preFirDiff(this->dataArray,period));//һ�ײ��
			this->dataFirDiff.assign(tmp.begin(), tmp.end());
			return this->dataFirDiff;
		}
				break;
		default: {
			//cout << " ��ֹ���:�����Բ�� " << endl;
			return preSeasonDiff(dataArray);//�����Բ��Ԥ��
			
		}
				 break;
		}
	}

	vector<int> getARIMAModel(int period, vector<vector<int> > notModel, bool needNot){

		vector<double> data = this->preDealDiff(period);//��ò������
		//for(int i=0;i<data.size();i++) cout<<data[i]<<endl;

		double minAIC = 1.7976931348623157E308;
		vector<int> bestModel(3);//0 1 2-->p q d
		int type = 0;
		vector<vector<double> > coe;

		// model����, ��������Ӧ��p, q����
		int len = data.size();//������ݵĳ���

		if (len > 6)
		{
			len = 5;
		}

		int size = ((len + 2) * (len + 1)) / 2 - 1;
		//int size=35;
		vector<vector<int> > model;
		model.resize(size);
		for (int i = 0; i<size; i++)
			model[i].resize(size);
		int cnt = 0;
		for (int i = 0; i <= len; ++i)
		{
			for (int j = 0; j <= len-i ; ++j)//len-i
			{
				if (i == 0 && j == 0)
					continue;
				model[cnt][0] = i;
			//	printf("model[%d][1]=%d\n", cnt, j);
				model[cnt++][1] = j;
				
			}
		}
		//cout<<size<<endl;
		//cout << " model.size()= " << model.size()<< "cnt="<<cnt<< endl;
		for (int i = 0; i < cnt; ++i)//model.size()--cnt
		{
			// ����ѡ��Ĳ���

			bool token = false;
			if (needNot)
			{
				for (int k = 0; k < notModel.size(); ++k)
				{
					if (model[i][0] == notModel[k][0] && model[i][1] == notModel[k][1])
					{
						token = true;
						break;
					}
				}
			}
			if (token)
			{
				continue;
			}

			if (model[i][0] == 0)
			{
				MAMoel* ma = new MAMoel(data, model[i][1]);

				//vector<vector<double>>
				coe = ma->solveCoeOfMA();
				// cout<<i<<coe.size()<<endl;
				//for(int ks=0;ks<ma->solveCoeOfMA().size();ks++) tmp.push_back(ma->solveCoeOfMA()[ks]);
				//coe.assign(tmp.begin(),tmp.end());
				type = 1;
			}
			else if (model[i][1] == 0)
			{
				ARModel* ar = new ARModel(data, model[i][0]);
				//vector<vector<double>> tmp(
				coe = ar->solveCoeOfAR();
				//   cout<<i<<coe.size()<<endl;
				//for(int ks=0;ks<ar->solveCoeOfAR().size();ks++) tmp.push_back(ar->solveCoeOfAR()[ks]);
				//coe.assign(tmp.begin(),tmp.end());
				type = 2;
			}
			else
			{
				//cout<<i<<model[i][0]<<" "<<model[i][1]<<endl;
				ARMAModel* arma = new ARMAModel(data, model[i][0], model[i][1]);;

				//vector<vector<double>> tmp(
				coe = arma->solveCoeOfARMA();
				//  cout<<i<<coe.size()<<endl;
				//for(int ks=0;ks<arma->solveCoeOfARMA().size();ks++) tmp.push_back(arma->solveCoeOfARMA()[ks]);
				//coe.assign(tmp.begin(),tmp.end());
				type = 3;
			}
			ARMAMath ar_math;
			double aic = ar_math.getModelAIC(coe, data, type);
			//cout<<aic<<endl;
			// �����������������ѡȡ���������ܻ����NAN�������������

			if (aic <= 1.7976931348623157E308 && !isnan(aic) && aic < minAIC)
			{
				minAIC = aic;
				// cout<<aic<<endl;
				bestModel[0] = model[i][0];
				bestModel[1] = model[i][1];
				bestModel[2] = (int)round(minAIC);
				this->arima = coe;
			}
		}
		return bestModel;
	}

	int aftDeal(int predictValue, int period){
		
		if (period >= dataArray.size())
		{
			period = 0;
		}

		switch (period)
		{
		case 0:
			return (int)predictValue;
		case 1:
			return (int)((0.4*predictValue + 0.6*dataArray[dataArray.size() - 1])*2);
		case 2:
		default:
			return (int)((0.4*predictValue + 0.6*dataArray[dataArray.size() - 2])*2);
		}
	}

	double gaussrand()
	{
		static double V1, V2, S;
		static int phase = 0;
		double X;

		if (phase == 0) {
			do {
				double U1 = (double)rand() / RAND_MAX;
				double U2 = (double)rand() / RAND_MAX;

				V1 = 2 * U1 - 1;
				V2 = 2 * U2 - 1;
				S = V1 * V1 + V2 * V2;
			} while (S >= 1 || S == 0);

			X = V1 * sqrt(-2 * log(S) / S);
		}
		else
			X = V2 * sqrt(-2 * log(S) / S);

		phase = 1 - phase;

		return X;
	}


	int predictValue(int p, int q, int period){
		vector<double> data(this->preDealDiff(period));
		int n = data.size();
		int predict = 0;
		double tmpAR = 0.0, tmpMA = 0.0;
		vector<double> errData(q + 1);

		if (p == 0)
		{
			vector<double> maCoe(this->arima[0]);
			for (int k = q; k < n; ++k)
			{
				tmpMA = 0;
				for (int i = 1; i <= q; ++i)
				{
					tmpMA += maCoe[i] * errData[i];
				}
				//��������ʱ�̵�����
				for (int j = q; j > 0; --j)
				{
					errData[j] = errData[j - 1];
				}
				errData[0] = gaussrand()*sqrt(maCoe[0]);
			}

			predict = (int)(tmpMA); //����Ԥ��
		}
		else if (q == 0)
		{
			vector<double> arCoe(this->arima[0]);

			for (int k = p; k < n; ++k)
			{
				tmpAR = 0;
				for (int i = 0; i < p; ++i)
				{
					tmpAR += arCoe[i] * data[k - i - 1];
				}
			}
			predict = (int)(tmpAR);
		}
		else
		{
			vector<double> arCoe(this->arima[0]);
			vector<double> maCoe(this->arima[1]);

			for (int k = p; k < n; ++k)
			{
				tmpAR = 0;
				tmpMA = 0;
				for (int i = 0; i < p; ++i)
				{
					tmpAR += arCoe[i] * data[k - i - 1];
				}
				for (int i = 1; i <= q; ++i)
				{
					tmpMA += maCoe[i] * errData[i];
				}

				//��������ʱ�̵�����
				for (int j = q; j > 0; --j)
				{
					errData[j] = errData[j - 1];
				}

				errData[0] = gaussrand() * sqrt(maCoe[0]);
			}

			predict = (int)(tmpAR + tmpMA);
		}

		return predict;
	}

};
#endif //ARIMAMODEL_H
