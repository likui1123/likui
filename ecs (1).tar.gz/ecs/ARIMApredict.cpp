//
// Created by yue on 18-3-16.
//

#include <vector>
#include "cstdio"
#include "iostream"
#include "ARIMAModel.h"
#include <math.h>



int predict(vector<double> dataArray){

	//double num[42]={1,2,3,4,4,2,34,25,25,4,5,25,2,52,6,426,34,3,2,5,25,2,52,35,25,25,2,5,26,2,5,2,3,62,5,23,52,6,57,547,5,2};
	//double gets;

	//vector<double> dataArray;
	//for(int i=0;i<42;i++)
		//dataArray.push_back(num[i]);

	ARIMAModel* arima = new ARIMAModel(dataArray);



	int period = 1;//����
	int modelCnt = 5;//ͨ�����Ԥ���ƽ��ֵ��ΪԤ��ֵ
	int cnt = 0;
	vector<vector<int> > list;
	vector<int> tmpPredict(modelCnt);

	for (int k = 0; k < modelCnt; ++k)			//����ͨ��������������м������յĽ��
	{
		
		vector<int> bestModel = arima->getARIMAModel(period, list, (k == 0) ? false : true);
		//cout<<bestModel.size()<<endl;
		period=1;
		if (bestModel.size() == 0)
		{
			
			tmpPredict[k] = (int)dataArray[dataArray.size() - period];
			cnt++;
			break;
		}
		else
		{
			//cout<<bestModel[0]<<bestModel[1]<<endl;
			int predictDiff = arima->predictValue(bestModel[0], bestModel[1], period);
			
			//int predictDiff = arima->predictValue(1, 1, period);
			//cout<<"fuck"<<endl;
			tmpPredict[k] = arima->aftDeal(predictDiff, period);
			cnt++;
		}
		//cout << bestModel[0] << " " << bestModel[1] << endl;
		list.push_back(bestModel);
		
	}

	double sumPredict = 0.0;
	for (int k = 0; k < cnt; ++k)
	{
		sumPredict += ((double)tmpPredict[k]) / (double)cnt;
	}
	int predict = (int)round(sumPredict);
	//cout << "Predict value=" << predict << endl;
	return predict;
}
