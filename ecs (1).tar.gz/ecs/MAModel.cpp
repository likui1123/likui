//
// Created by yue on 18-3-16.
//

#include "MAModel.h"


MAMoel::MAMoel(vector<double> data, int p) {
	this->data = data;
	this->p = p;
}

vector<vector<double>> MAMoel::solveCoeOfMA() {
	vector<vector<double> > vec;
	ARMAMath ar_math;
	vector<double>  maCoe(ar_math.computeMACoe(this->data, this->p));
	vec.push_back(maCoe);
	return vec;
}