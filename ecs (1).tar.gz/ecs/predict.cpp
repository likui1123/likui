#include "predict.h"
#include "allocate.h"
#include "ARIMAModel.h"
struct PhyInfo{
    int phycpu;
    int phymem;
    int phyhard;
} phyinfo;
struct FlavorsInfo{
    vector<string> vflavors;
    vector<int> vcpus, vmems;
} flavorsinfo;

int predict_daySpan, history_daySpan;
vector<string> vflavors;
vector<int> vflavors_pridict_nums;
vector<int>    vcpus, vmems;
string dim, predict_begin_time, predict_end_time, history_begin_time, history_end_time;
vector< vector<int> > sequences;
time_t predict_begin_time_t, predict_end_time_t, history_begin_time_t, history_end_time_t;
int oneDayLong = 24 * 3600; //s

void predict_server(char * info[MAX_INFO_NUM], char * data[MAX_DATA_NUM], int data_num, char * filename)
{
    get_info(info);
    get_data(data, data_num);
   my_predict();

	//my_predict_w_trained()
	//gray_predict();
    allocate_simple(vflavors, vflavors_pridict_nums, dim, filename);

//	char * result_file = (char *)"17\n\n0 8 0 20";
//	write_result(result_file, filename);
}
void my_predict()
{
    // init sequences
    vector< vector<int> > daySpan_sequences;
    for(int i=0; i<sequences.size(); i++)
    {
        vector<int> daySpan_sequence;
        //累加predict_daySpan内的记录数
        for(int j=0; j<sequences[i].size()-predict_daySpan+1; j++)
        {
           daySpan_sequence.push_back(accumulate(sequences[i].begin()+j, sequences[i].begin()+j+predict_daySpan, 0));
		//daySpan_sequence.push_back(sequences[i]);
        }
        daySpan_sequences.push_back(daySpan_sequence);
    }
    cout << "daySpan_sequences: " << endl;
    for(int i=0; i<daySpan_sequences.size(); i++)
    {
        cout << vflavors[i] << endl;
	vector<double> temp(daySpan_sequences[i].size()-33,0);

       for(int j=0; j<daySpan_sequences[i].size(); j++)
       {   
           //cout << daySpan_sequences[i][j] << ", ";
	    temp.push_back(daySpan_sequences[i][j]);
	    //temp[j]=daySpan_sequences[i][j];
        }

      for(int j=0; j<predict_daySpan-1; j++)
      {

        cout<<predict(temp)<<"  ";
	 int sum = accumulate(temp.begin(), temp.end(), 0);
         float average = (float)sum/temp.size();
	 int result=predict(temp);
	
	if(result-average<10)
       {
	     temp.push_back(result);		
       }

      }cout<<endl;
	//vector<double> temp = temp[i]; 
	vflavors_pridict_nums.push_back(predict(temp));
        cout << endl;
    }
    for(int i=0; i<vflavors.size(); i++)
    {
        cout << vflavors[i] << ":\t" << vflavors_pridict_nums[i] << endl;
    }
/*

    for(int i=0; i<daySpan_sequences.size(); i++)
    {
        vector<int> temp = daySpan_sequences[i];  //temp for daySpan_sequences
        for(int j=0; j<predict_daySpan; j++)
        {
            int sum = accumulate(temp.begin(), temp.end(), 0);
            float average = (float)sum/temp.size();
            float last_daySpan = temp.back();

            float w_average = 0.4;
            float w_last_daySpan = 0.6;
            int predict_result = round(w_average * average + w_last_daySpan * last_daySpan);
//            cout << predict_result;
            temp.push_back(predict_result);
        }
        vflavors_pridict_nums.push_back(temp.back());
    }

    for(int i=0; i<vflavors.size(); i++)
    {
        cout << vflavors[i] << ":\t" << vflavors_pridict_nums[i] << endl;
    }
*/
}


void get_info(char * info[MAX_INFO_NUM])
{
    int num_of_vm;

    string line = info[0];
    int firstSpace = line.find_first_of(' ');
    int secondSpace = line.find_last_of(' ');
    phyinfo.phycpu = atoi(line.substr(0,firstSpace).c_str());
    phyinfo.phymem = atoi(line.substr(firstSpace+1, secondSpace-firstSpace-1).c_str())*1024; //MB
    phyinfo.phyhard = atoi(line.substr(secondSpace+1).c_str());

    line = info[2];
    num_of_vm = atoi(line.c_str());

    for(int i=3; i<3+num_of_vm; i++)
    {
        line = info[i];
        int firstSpace = line.find_first_of(' ');
        int secondSpace = line.find_last_of(' ');
        vflavors.push_back(line.substr(0,firstSpace));
        vcpus.push_back(atoi(line.substr(firstSpace+1, secondSpace-firstSpace-1).c_str()));
        vmems.push_back(atoi(line.substr(secondSpace+1).c_str()));
    }

    flavorsinfo.vflavors = vflavors;
    flavorsinfo.vcpus = vcpus;
    flavorsinfo.vmems = vmems;

    dim = info[3+num_of_vm+1];
    predict_begin_time = info[3+num_of_vm+3];
    predict_end_time = info[3+num_of_vm+4];
    predict_begin_time_t = str2time(predict_begin_time.c_str(), "%Y-%m-%d %H:%M:%S");
    predict_end_time_t = str2time(predict_end_time.c_str(), "%Y-%m-%d %H:%M:%S");
    predict_daySpan = ceil((float)(predict_end_time_t - predict_begin_time_t)/oneDayLong);

    cout << "phycpu: " << phyinfo.phycpu << endl;
    cout << "phymem: " << phyinfo.phymem << endl;
    cout << "phyhard: " << phyinfo.phyhard << endl;
    cout << "num_of_vm: " << num_of_vm << endl;
    for(int i=0; i<vflavors.size(); i++)
    {
        cout << vflavors[i]<<" "<< vcpus[i] << " " << vmems[i]<<endl;
    }
    cout << "dim: " << dim <<endl;
    cout << "predict_begin_time: " << predict_begin_time << endl;
    cout << "predict_end_time: " << predict_end_time << endl;
    cout << "predict_daySpan: " << predict_daySpan << endl;
}
void get_data(char * data[MAX_DATA_NUM], int data_num)
{
    string line = data[0];
    int firstTab = line.find_first_of('\t');
    int secondTab = line.find_last_of('\t');
    int lastSpace = line.find_last_of(' ');
    history_begin_time = line.substr(secondTab+sizeof("\t")-1, lastSpace-secondTab-1);
    history_begin_time.append(" 00:00:00");
    cout << history_begin_time <<endl;
    line = data[data_num-1];
    firstTab = line.find_first_of('\t');
    secondTab = line.find_last_of('\t');
    lastSpace = line.find_last_of(' ');
    history_end_time = line.substr(secondTab+sizeof("\t")-1, lastSpace-secondTab-1);
    history_end_time.append(" 23:59:59");
    cout << history_end_time <<endl;

    history_begin_time_t = str2time(history_begin_time.c_str(), "%Y-%m-%d %H:%M:%S");
    cout << history_begin_time_t << endl;
    history_end_time_t = str2time(history_end_time.c_str(), "%Y-%m-%d %H:%M:%S");
    cout << history_end_time_t << endl;
    history_daySpan = ceil((float)(history_end_time_t - history_begin_time_t)/oneDayLong);
    cout << "history_daySpan: " << history_daySpan << endl;

    // get sequences
    for(int i=0; i<vflavors.size(); i++)
    {
        vector<int> sequence(history_daySpan, 0); //history_daySpan ints with value 0;
        //search data
        for(int j=0; j<data_num; j++)
        {
            string line = data[j];
            int firstTab = line.find_first_of('\t');
            int secondTab = line.find_last_of('\t');
            int lastSpace = line.find_last_of(' ');
            string vflavor = line.substr(firstTab+sizeof("\t")-1, secondTab-firstTab-sizeof("\t")+1);
            time_t time =  str2time(line.substr(secondTab+sizeof("\t")-1, lastSpace-secondTab-1).append(" 00:00:00").c_str(), "%Y-%m-%d %H:%M:%S");
            int dayDiff = (time - history_begin_time_t)/oneDayLong; // used as sequence index
//            cout << vflavor << "\t" << time << "\t" << dayDiff << endl;
            if(vflavor == vflavors[i]) //this kind of flavor need to be predicted
            {
                sequence[dayDiff]++;   //add a record at daydiff index
            }
        }
        sequences.push_back(sequence);
    }

    for(int i=0; i<sequences.size(); i++)
    {
        cout << vflavors[i] << endl;
        int sum = 0;
        for(int j=0; j<sequences[i].size(); j++)
        {
            sum += sequences[i][j];
            cout << sequences[i][j] << ", ";
        }
        cout << "total_num: " << sum << endl;
        cout << endl;
    }
}

time_t str2time(string str, string format)
{
    struct tm *tmp_time = (struct tm*)malloc(sizeof(struct tm));
    strptime(str.c_str(), format.c_str(), tmp_time);
    time_t t = mktime(tmp_time);
    free(tmp_time);
    return t;
}
