//
// Created by yue on 18-3-16.
//

#ifndef ARMODEL_H
#define ARMODEL_H

#include <vector>
#include "ARMAMath.h"

class ARModel{
private:
	vector<double> data;
	int p;

public:
	ARModel(vector<double> data, int p){
		this->data.assign(data.begin(), data.end());
		this->p = p;
	}

	vector<vector<double> > solveCoeOfAR(){
		vector<vector<double> > vec;
		ARMAMath ar_math;
		vector<double>  arCoe(ar_math.computeARCoe(this->data, this->p));
		vec.push_back(arCoe);
		return vec;
	}
};


#endif //ARMODEL_H
