/*************************************************************************
> File Name: ARMAMath.h
> Author: yue
> Mail:
> Created Time: 2018��03��15�� ������ 13ʱ44��00��
************************************************************************/

#ifndef _ARMAMATH_H
#define _ARMAMATH_H

#include <vector>
using namespace std;

	double average(vector<double> ,int);
	
	double variance(vector<double> ,int);
	vector<double>  autocor(vector<double> , int,int );

	//double getModelAIC(vector<vector<double> > , vector<double> , int,int );
	vector<double> aicCheck(vector<vector<double> > , vector<double> , int,int );

	std::vector<vector<double> > LevinsonSolve(vector<double> );
	vector<double> getParaAr(vector<double> , int,int,int,int );


	vector<vector<double>> optiData(vector<double> gar,int o,int t);





#endif

