#ifndef PUT_FLAVORS_H
#define PUT_FLAVORS_H
#include <stdio.h>
#include <iostream>
#include "lib_io.h"
#include <vector>
#include <string>
#include <numeric>
#include <cstring>

using namespace std;

int put_flavors(vector<string> flavor, vector<int> flavorPridictResult, string dim, char* filename);
#endif // ALLOCATE_H
